## Shopper includes these public works

For Frappe Framework, please see attributions.md at https://github.com/sparrownova/frappe/

#### Images

POS Icon: https://thenounproject.com/icon/41958 by hunotika
